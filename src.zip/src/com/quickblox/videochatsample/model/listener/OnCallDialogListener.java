package com.quickblox.videochatsample.model.listener;

/**
 * Created with IntelliJ IDEA.
 * User: Andrew Dmitrenko
 * Date: 7/23/13
 * Time: 11:05 AM
 */
public interface OnCallDialogListener {

    public void onAcceptCallClick();
    public void onRejectCallClick();
}
